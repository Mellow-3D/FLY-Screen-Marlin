#ifndef __GCODELOGIC_H__
#define __GCODELOGIC_H__


void sendfail();
#endif /*__GCODELOGIC_H__ */
