#pragma once
#include "uart/ProtocolSender.h"
#include "storage/StoragePreferences.h"
#include "uart/UartContext.h"
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include "security/SecurityManager.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include "utils/BrightnessHelper.h"
#include "entry/EasyUIContext.h"
#include "manager/ConfigManager.h"
#include "os/MountMonitor.h"
#include <algorithm>
// 设备 id 共8个字节
	  unsigned char devID[8];
	  // 成功返回 true，失败返回 false
	  bool ret = SECURITYMANAGER->getDevID(devID);
	  void setflyImage(ZKBase* pCtrl, const string& fileName, bool isThumbnail);
	  char id[100];
	  char key2[]="4937732348172104228,5062752348172104228,4988712348172104228,5070752348172104228,5168312348172104228"
	  "4959312348172104228,4949312348172104228,5160312348172104228,4951972348172104228,4973512348172104228,4958762348172104228"
	  "4973202348172104228,4970972348172104228,4924512348172104228,4925712348172104228,4974312348172104228,4988452348172104228"
	  "5021222348172104228,4972442348172104228,4992742348172104228,514572131210148104228,516356131210148104228,4937282348172104228"
	  "4852682348172104228,4751502348172104228,4786262348172104228,4929602348172104228,4746502348172104228,4968132348172104228"
	  "391140754968105228,4922802348172104228,4934732348172104228,499512348172104228,4917512348172104228,5065492348172104228"
	  "4940602348172104228,5361792348172104228,4851757113160105228,4913367113160105228,47468339130172105228,47586439130172105228"
	  "45588739130172105228,39759439130172105228,39439539130172105228,47865839130172105228,47398439130172105228,47268739130172105228"
	  "47755639130172105228,39579339130172105228,39649539130172105228,39525739130172105228,47116239130172105228,51468131210148104228"
	  "4376571981108105228,39328639130172105228,47165639130172105228,45848539130172105228,39105039130172105228,39854439130172105228"
	  "39954439130172105228,45518639130172105228,45496539130172105228,45446539130172105228,47805139130172105228,47615039130172105228"
	  "47327639130172105228,37234339130172105228,47272339130172105228,47702339130172105228,47581939130172105228,34696139130172105228"
	  "45464539130172105228,39188339130172105228,45844539130172105228,34454339130172105228,39269239130172105228,47798439130172105228"
	  "47666339130172105228,45624539130172105228,39708239130172105228,34636239130172105228,48569739130172105228,34806239130172105228"
	  "47828239130172105228,47568139130172105228,34856139130172105228,39645939130172105228,45625239130172105228,47364439130172105228"
	  "37454639130172105228,39736839130172105228,39416839130172105228,45788739130172105228,47876139130172105228,4380201981108105228"
	  "45238839130172105228,39153939130172105228,45568839130172105228,39643939130172105228,48479639130172105228,34763339130172105228"
	  "45416839130172105228,47496339130172105228,47498839130172105228,3484239130172105228,39433139130172105228,45176839130172105228"
	  "3975839130172105228,34637739130172105228,47633439130172105228,45363939130172105228,49587839130172105228,34173739130172105228,"
	  "34207739130172105228,34347839130172105228,34294239130172105228,39445239130172105228,34204239130172105228,39753939130172105228,"
	  "49521539130172105228,47976239130172105228,45698039130172105228,47626239130172105228,47546139130172105228,47113239130172105228,"
	  "47511139130172105228,47895639130172105228,47326139130172105228,39234839130172105228,45655639130172105228,34463639130172105228,"
	  "34394339130172105228,34767839130172105228,39644839130172105228,45184839130172105228,39905239130172105228,39515139130172105228,"
	  "47271739130172105228,34233339130172105228,47501639130172105228,39143939130172105228,34633739130172105228,34237739130172105228"
      "5490287113160105228,45926339130172105228,45596339130172105228,45816439130172105228,39745239130172105228,47386839130172105228"
	  "45945739130172105228,47636739130172105228,39917639130172105228,47185739130172105228,45533339130172105228,39318339130172105228"
      "39228739130172105228,34715939130172105228,34195939130172105228,45373339130172105228,4766839130172105228,39338239130172105228"
	  "34886039130172105228,34366039130172105228,39914739130172105228,47401039130172105228,47551339130172105228,48539939130172105228"
	  "4764939130172105228,45143439130172105228,39168239130172105228,39848239130172105228,39204439130172105228,47465839130172105228"
	  "47388639130172105228,34376139130172105228,40629939130172105228,4537339130172105228,45286939130172105228,45497039130172105228"
	  "4559839130172105228,39315839130172105228,39505939130172105228,47298639130172105228,347768339130172105228,34556039130172105228"
	  "34553739130172105228,3922739130172105228,51784239130172105228,46273739130172105228,34435139130172105228,34126039130172105228"
	  "34223639130172105228,34456139130172105228,39125939130172105228,37684239130172105228,34606939130172105228,39237739130172105228"
      "47672839130172105228,45256839130172105228,34544739130172105228,47701439130172105228,39771739130172105228,47202839130172105228"
	  "47202839130172105228,39477639130172105228,47806839130172105228,34886139130172105228,34125039130172105228,45644939130172105228"
	  "39584239130172105228,49721639130172105228,47312639130172105228,45317739130172105228,45317739130172105228,37904139130172105228"
      "39645539130172105228,39461839130172105228,45435839130172105228,34337939130172105228,3484839130172105228,47332539130172105228"
      "45305839130172105228,47797739130172105228,45628539130172105228，39917539130172105228,47217739130172105228,45195939130172105228"
      "3465139130172105228,34744939130172105228,47637739130172105228,34414939130172105228,45416539130172105228,46513739130172105228"
      "34404939130172105228,39481639130172105228,34396939130172105228,47307839130172105228,34657039130172105228,45165939130172105228"
      "45166039130172105228,34467039130172105228,47552639130172105228,46268939130172105228,39221839130172105228,34705039130172105228"
	  "34277839130172105228,47611739130172105228,47511739130172105228,4060122072009696228,4088822072009696228,4049852072009696228"
      "4023852072009696228,4068122072009696228,4028632072009696228,4083822072009696228,416082072009696228,4033852072009696228"
      "4078812072009696228,4076822072009696228,4032912072009696228,3955992072009696228,4054592072009696228,4029912072009696228"
      "4327862072009696228,4453862072009696228,4042852072009696228,4072652072009696228,3952982072009696228,4012632072009696228"
	  "4422572072009696228,4047852072009696228,39507539130172105228,34277839130170105228,45276139130172105228,416082072009696228,"
	  "4049852072009696228,47467739130172105228,34915039130172105228,4067122072009696228,415182072009696228,47903139130172105228,"
	  "45226139130172105228,34365039130172105228,39688039130172105228,47282439130172105228,4078812072009696228,34686839130172105228,"
	  "3954992072009696228,4031852072009696228,4041852072009696228,4433502072009696228,4051122072009696228,4341902072009696228,"
      "3939962072009696228,416392072009696228,4023912072009696228,4449142072009696228,3961982072009696228,4313562072009696228"
	  "4036852072009696228,4034122072009696228,4057852072009696228,4039852072009696228,4086822072009696228,4130162072009696228"
	  "40329020720096962284069652072009696228,4025852072009696228,4081822072009696228,4060652072009696228,4026852072009696228"
      "4050852072009696228,4087622072009696228,4055852072009696228,4336862072009696228,414882072009696228,3944982072009696228"
      "4065822072009696228,4015632072009696228,4073822072009696228,4069822072009696228,4034852072009696228,4080652072009696228"
	  "3979362072009696228,4051592072009696228,3964992072009696228,4352862072009696228,4040912072009696228,445782072009696228"
	  "4083812072009696228,414472072009696228,4041902072009696228,4038902072009696228,4043122072009696228,4064652072009696228"
	  "4023632072009696228,4076332072009696228,4472182151486896228,5766657120810496228,5688527120810496228,47451007120810496228"
	  "4878627120810496228,50455419116596228,4772477120810496228,4067592072009696228,5579587120810496228,4441142072009696228,"
	  "4082622072009696228,3955802072009696228,5582447120810496228";
	  /*
*此文件由GUI工具生成
*文件功能：用于处理用户的逻辑相应代码
*功能说明：
*========================onButtonClick_XXXX
当页面中的按键按下后系统会调用对应的函数，XXX代表GUI工具里面的[ID值]名称，
如Button1,当返回值为false的时候系统将不再处理这个按键，返回true的时候系统将会继续处理此按键。比如SYS_BACK.
*========================onSlideWindowItemClick_XXXX(int index) 
当页面中存在滑动窗口并且用户点击了滑动窗口的图标后系统会调用此函数,XXX代表GUI工具里面的[ID值]名称，
如slideWindow1;index 代表按下图标的偏移值
*========================onSeekBarChange_XXXX(int progress) 
当页面中存在滑动条并且用户改变了进度后系统会调用此函数,XXX代表GUI工具里面的[ID值]名称，
如SeekBar1;progress 代表当前的进度值
*========================ogetListItemCount_XXXX() 
当页面中存在滑动列表的时候，更新的时候系统会调用此接口获取列表的总数目,XXX代表GUI工具里面的[ID值]名称，
如List1;返回值为当前列表的总条数
*========================oobtainListItemData_XXXX(ZKListView::ZKListItem *pListItem, int index)
 当页面中存在滑动列表的时候，更新的时候系统会调用此接口获取列表当前条目下的内容信息,XXX代表GUI工具里面的[ID值]名称，
如List1;pListItem 是贴图中的单条目对象，index是列表总目的偏移量。具体见函数说明
*========================常用接口===============
*LOGD(...)  打印调试信息的接口
*mTextXXXPtr->setText("****") 在控件TextXXX上显示文字****
*mButton1Ptr->setSelected(true); 将控件mButton1设置为选中模式，图片会切换成选中图片，按钮文字会切换为选中后的颜色
*mSeekBarPtr->setProgress(12) 在控件mSeekBar上将进度调整到12
*mListView1Ptr->refreshListView() 让mListView1 重新刷新，当列表数据变化后调用
*mDashbroadView1Ptr->setTargetAngle(120) 在控件mDashbroadView1上指针显示角度调整到120度
*
* 在Eclipse编辑器中  使用 “alt + /”  快捷键可以打开智能提示
*/




	  static std::string sContentStr;//键盘相关设置
	  static void addOneChar(char ch) {
	  	sContentStr += ch;
	  	mTextView22Ptr->setText(sContentStr);
	  	mTextView46Ptr->setText(sContentStr);
	  }

	  static void delOneChar() {
	  	if (!sContentStr.empty()) {
	  		sContentStr.erase(sContentStr.length() - 1, 1);
	  		mTextView22Ptr->setText(sContentStr);
	  		mTextView46Ptr->setText(sContentStr);
	  	}
	  }
	  string fn = "A4MAX.fly3d";//预览图片
struct TempItem {	//温度项
	string name;	//每一项的名字，:前面的，如果只有/，那么这个为空
	string value;	//后面的浮点数
};

struct AxIs {
	string axis;
	string va;
};
typedef struct {
	const char* mainText;
	bool bOn;
} S_TEST_DATA;
static S_TEST_DATA sDataTestTab[] = {
	{ "100mm", false },
	{ "10mm", true },
	{ "1mm", false },
	{ "0.1mm", false },
};

typedef struct {
	const char* mainText;
	bool bOn;
} PLAABS;

typedef struct {
	const char* mainText;
	bool bOn;
} eaxis;


string gmla;
int gindex=1;

vector<string> strs;
vector<string> gcodes; vector<string> temp;vector<string> activetemp; vector<string> pos;int gcodenum = 0,currmode = 0 ,xzgcodenum= 0,noprint = 0;
//                              temp储存喷头温度                   temp储存喷头活动温度                                            pos XYZ坐标//gcode文件条数  //当前模式，主板sd卡，屏幕sd卡//当前选中的主板gcode列表条数
vector<string> maxspeeds;
vector<string> PID;
vector<string> STEP;
	typedef struct {
		const char* mainText;
		const char* nrText;
	} gcodeml;
static gcodeml Gcode[] ={
		{"	G0 & G1: Move	"},
		{"	G2 & G3: Controlled Arc Move	"},
		{"	G4: Dwell	"},
		{"	G10: Tool Offset and Temperature Setting	"},
		{"	G10: Set workplace coordinate offset or tool offset	"},
		{"	G10: Retract	"},
		{"	G11: Unretract	"},
		{"	G17: Select XY plane for arc moves	"},
		{"	G20: Set Units to Inches	"},
		{"	G21: Set Units to Millimeters	"},
		{"	G28: Home	"},
		{"	G29: Mesh bed probe	"},
		{"	G30: Single Z-Probe	"},
		{"	G31: Set or Report Current Probe status	"},
		{"	G32: Run bed.g macro	"},
		{"	G38.2 to G38.5: Straight Probe	"},
		{"	G53 Use machine coordinates	"},
		{"	G54 to G59.3: Select coordinate system	"},
		{"	G60: Save current position to slot	"},
		{"	G90: Set to Absolute Positioning	"},
		{"	G91: Set to Relative Positioning	"},
		{"	G92: Set Position	"},
		{"	M0: Stop or Unconditional stop	"},
		{"	M1: Sleep or Conditional stop	"},
		{"	M3: Spindle On, Clockwise (CNC specific)/ Laser on (Laser specific)	"},
		{"	M4: Spindle On, Counterclockwise (CNC specific)	"},
		{"	M5: Spindle Off (CNC specific), laser off (Laser specific)	"},
		{"	M18: Disable all stepper motors	"},
		{"	M20: List SD card	"},
		{"	M21: Initialize SD card	"},
		{"	M22: Release SD card	"},
		{"	M23: Select SD file	"},
		{"	M24: Start/resume SD print	"},
		{"	M25: Pause SD print	"},
		{"	M26: Set SD position	"},
		{"	M27: Report SD print status	"},
		{"	M28: Begin write to SD card	"},
		{"	M29: Stop writing to SD card	"},
		{"	M30: Delete a file on the SD card	"},
		{"	M32: Select file and start SD print	"},
		{"	M36: Return file information	"},
		{"	M37: Simulation mode	"},
		{"	M38: Compute SHA1 hash of target file	"},
		{"	M39: Report SD card information	"},
		{"	M42: Switch I/O pin	"},
		{"	M80: ATX Power On	"},
		{"	M81: ATX Power Off	"},
		{"	M82: Set extruder to absolute mode	"},
		{"	M83: Set extruder to relative mode	"},
		{"	M84: Stop idle hold	"},
		{"	M92: Set axis steps per unit	"},
		{"	M98: Call Macro/Subprogram	"},
		{"	M99: Return from Macro/Subprogram	"},
		{"	M104: Set Extruder Temperature	"},
		{"	M105: Get Extruder Temperature	"},
		{"	M106: Fan On	"},
		{"	M107: Fan Off	"},
		{"	M108: Cancel Heating	"},
		{"	M109: Set Extruder Temperature and Wait	"},
		{"	M110: Set Current Line Number	"},
		{"	M111: Set Debug Level	"},
		{"	M112: Emergency Stop	"},
		{"	M114: Get Current Position	"},
		{"	M115: Get Firmware Version and Capabilities	"},
		{"	M116: Wait	"},
		{"	M117: Display Message	"},
		{"	M118: Send Message to Specific Target	"},
		{"	M119: Get Endstop Status	"},
		{"	M120: Push	"},
		{"	M121: Pop	"},
		{"	M122: Diagnose	"},
		{"	M135: Set PID sample interval	"},
		{"	M140: Set Bed Temperature (Fast) or Configure Bed Heater	"},
		{"	M141: Set Chamber Temperature (Fast) or Configure Chamber Heater	"},
		{"	M143: Maximum heater temperature	"},
		{"	M143 in RRF 3.01RC1 and earlier	"},
		{"	M143 in RRF 3.01RC2 and later	"},
		{"	M144: Bed Standby	"},
		{"	M150: Set LED colours	"},
		{"	M190: Wait for bed temperature to reach target temp	"},
		{"	M191: Wait for chamber temperature to reach target temp	"},
		{"	M200: Set filament diameter	"},
		{"	M201: Set max acceleration	"},
		{"	M203: Set maximum feedrate	"},
		{"	M204: Set printing and travel accelerations	"},
		{"	M205: Set max instantaneous speed change in mm/sec	"},
		{"	M206: Offset axes	"},
		{"	M207: Set retract length	"},
		{"	M208: Set axis max travel	"},
		{"	M220: Set speed factor override percentage	"},
		{"	M221: Set extrude factor override percentage	"},
		{"	M226: Synchronous Pause	"},
		{"	M260: i2c Send and/or request Data	"},
		{"	M261: i2c Request Data	"},
		{"	M280: Set servo position	"},
		{"	M290: Baby stepping	"},
		{"	M291: Display message and optionally wait for response	"},
		{"	M292: Acknowledge message	"},
		{"	M300: Play beep sound	"},
		{"	M301: Set PID parameters	"},
		{"	M302: Allow cold extrudes	"},
		{"	M303: Run heater tuning	"},
		{"	M304: Set PID parameters - Bed	"},
		{"	M305: Set temperature sensor parameters	"},
		{"	M307: Set or report heating process parameters	"},
		{"	M308: Set or report sensor parameters	"},
		{"	M350: Set microstepping mode	"},
		{"	M374: Save height map	"},
		{"	M375: Load height map	"},
		{"	M376: Set bed compensation taper	"},
		{"	M400: Wait for current moves to finish	"},
		{"	M401: Deploy z-probe	"},
		{"	M402: Retract z-probe	"},
		{"	M404: Filament width and nozzle diameter	"},
		{"	M408: Report JSON-style response	"},
		{"	M409: Query object model	"},
		{"	M450: Report Printer Mode	"},
		{"	M451: Select FFF Printer Mode	"},
		{"	M452: Select Laser DeviceMode	"},
		{"	M453: Select CNC Device Mode	"},
		{"	M453 in RepRapFirmware 1.x and 2.x	"},
		{"	M453 in RepRapFirmware 3.0 and 3.1.x	"},
		{"	M453 in RepRapFirmware 3.2 and later	"},
		{"	M470: Create Directory on SD-Card	"},
		{"	M471: Rename File/Directory on SD-Card	"},
		{"	M486: Object cancellation	"},
		{"	M500: Store parameters	"},
		{"	M501: Read stored parameters	"},
		{"	M502: Revert stored parameters	"},
		{"	M503: Print settings	"},
		{"	M505: Set configuration file folder	"},
		{"	M540: Set MAC address	"},
		{"	M550: Set Name	"},
		{"	M551: Set Password	"},
		{"	M552: Set IP address, enable/disable network interface	"},
		{"	M553: Set Netmask	"},
		{"	M554: Set Gateway	"},
		{"	M555: Set compatibility	"},
		{"	M556: Axis skew compensation	"},
		{"	M557: Set Z probe point or define probing grid	"},
		{"	M558: Set Z probe type	"},
		{"	M558 in RepRapFirmware 2.x and earlier	"},
		{"	M558 in RepRapFirmware 3	"},
		{"	M559: Upload file	"},
		{"	M560: Upload file	"},
		{"	M561: Set Identity Transform	"},
		{"	M562: Reset temperature fault	"},
		{"	M563: Define or remove a tool	"},
		{"	M564: Limit axes	"},
		{"	M566: Set allowable instantaneous speed change	"},
		{"	M567: Set tool mix ratios	"},
		{"	M568: Turn off/on tool mix ratios	"},
		{"	M569: Set motor driver direction, enable polarity and step pulse timing	"},
		{"	M569.1: Stepper driver closed loop control	"},
		{"	M570: Configure heater fault detection	"},
		{"	M571: Set output on extrude	"},
		{"	M572: Set or report extruder pressure advance	"},
		{"	M573: Report heater PWM	"},
		{"	M574: Set endstop configuration	"},
		{"	M574 - RepRapFirmware 2.x and earlier	"},
		{"	M574 - RepRapFirmware 3	"},
		{"	M575: Set serial comms parameters	"},
		{"	M577: Wait until endstop is triggered	"},
		{"	M577 - RepRapFirmware 2.x and earlier	"},
		{"	M577 - RepRapFirmware 3.0 up to 3.01RC1	"},
		{"	M577 - RepRapFirmware 3.01RC2 and later	"},
		{"	M578: Fire inkjet bits	"},
		{"	M579: Scale Cartesian axes	"},
		{"	M580: Select Roland	"},
		{"	M581: Configure external trigger	"},
		{"	M581 - RepRapFirmware 2.x and earlier	"},
		{"	M581 - RepRapFirmware 3.0 to 3.01RC1 (but not 3.01RC2 and later)	"},
		{"	M581 - RepRapFirmware 3.01RC2 and later	"},
		{"	M582: Check external trigger	"},
		{"	M584: Set drive mapping	"},
		{"	M585: Probe Tool	"},
		{"	M586: Configure network protocols	"},
		{"	M587: Add WiFi host network to remembered list, or list remembered networks	"},
		{"	M588: Forget WiFi host network	"},
		{"	M589: Configure access point parameters	"},
		{"	M591: Configure filament sensing	"},
		{"	M591 - RepRapFirmware 3	"},
		{"	M591 - RepRapFirmware 1.21 to 2.x	"},
		{"	M591 - RepRapFirmware 1.20 and earlier	"},
		{"	M592: Configure nonlinear extrusion	"},
		{"	M593: Configure Dynamic Acceleration Adjustment	"},
		{"	M594: Enter/Leave Height Following mode	"},
		{"	M600: Filament change pause	"},
		{"	M650: Set peel move parameters	"},
		{"	M651: Execute peel move	"},
		{"	M665: Set delta configuration	"},
		{"	M666: Set delta endstop adjustment	"},
		{"	M667: Select CoreXY or related mode	"},
		{"	M669: Set kinematics type and kinematics parameters	"},
		{"	M670: Set IO port bit mapping	"},
		{"	M671: Define positions of Z leadscrews or bed levelling screws	"},
		{"	M672: Program Z probe	"},
		{"	M673: Align plane on rotary axis	"},
		{"	M674: Set Z to center point	"},
		{"	M675: Find center of cavity	"},
		{"	M701: Load filament	"},
		{"	M702: Unload filament	"},
		{"	M703: Configure filament	"},
		{"	M750: Enable 3D scanner extension	"},
		{"	M751: Register 3D scanner extension over USB	"},
		{"	M752: Start 3D scan	"},
		{"	M753: Cancel current 3D scanner action	"},
		{"	M754: Calibrate 3D scanner	"},
		{"	M755: Set alignment mode for 3D scanner	"},
		{"	M756: Shutdown 3D scanner	"},
		{"	M851: Set Z-Probe Offset (Marlin Compatibility)	"},
		{"	M905: Set local date and time	"},
		{"	M906: Set motor currents	"},
		{"	M911: Configure auto save on loss of power	"},
		{"	M912: Set electronics temperature monitor adjustment	"},
		{"	M913: Set motor percentage of normal current	"},
		{"	M914: Set/Get Expansion Voltage Level Translator	"},
		{"	M915: Configure motor stall detection	"},
		{"	M916: Resume print after power failure	"},
		{"	M917: Set motor standstill current reduction	"},
		{"	M918: Configure direct-connect display	"},
		{"	M929: Start/stop event logging to SD card	"},
		{"	M950: Create heater, fan or GPIO/servo pin	"},
		{"	M951: Set height following mode parameters	"},
		{"	M952: Set CAN-FD expansion board address and/or normal data rate	"},
		{"	M953: Set CAN-FD bus fast data rate	"},
		{"	M997: Perform in-application firmware update	"},
		{"	M998: Request resend of line	"},
		{"	M999: Restart	"},
		{"	T: Select Tool	"},

};




typedef struct {
	const char* mainText;
	bool bOn;
} eaxisex;



/**
 * 注册定时器
 * 填充数组用于注册定时器
 * 注意：id不能重复
 */
static S_ACTIVITY_TIMEER REGISTER_ACTIVITY_TIMER_TAB[] = {
	{0,  1000},//定时器id=0,
	{1,  100},
	{2,  50},
	{3,  10000},
};

static string printerCode;
static string gcode;
static vector<TempItem> tempItems;
static vector<AxIs> Axis;

enum FileType { E_FILETYPE_HOME, E_FILETYPE_BACK, E_FILETYPE_FOLDER, E_FILETYPE_FILE, E_FILETYE_MAX };

struct FileInfo {
	string fileName;
	FileType fileType;
	long datetime;
};
bool compare(const FileInfo& inf1, const FileInfo& inf2) {
	return inf1.datetime > inf2.datetime;
}

char pmtimed[100];


int whT=0;//维护界面左右转换T
  int times = 0,timef = 0,timeh = 0,timet = 0,dytime=0,sytime=0;


   int backok=0;
   int TR=0,TL=0;
   int whclsdds=600,whclsdcs=1200,whclsdgs=2400;
 int SETT0=200,SETT1=200,SETT2=200,SETT3=200,SETT4=200,SETB0=60,cl=300;//预热温度
 int ld=0,kg=0,kg1=0,kg3=0,kg4=0,jiaodu=0,lockkg=0,tempkg=0,printstop=0,zkg=0,statkg=0,printok=0,printcel=0,M104kg=0,M140kg=0;
 int fsfail=0;//发送失败标志
 int homeok=0,tempnum=1,busy=0;
 int printsp=100;
 float jl = 10,zgd=0;
 int currentLine = 0;
 int filesize = 0;//文件总大小用于计算进度条
 int curfilesize = 0;
 int curprintcs = 0;//当前打印按钮参数设置

 //这里的参数为温度设置
 int tempptwd = 200;
 int temprcwd = 60;





 //这里的参数为维护里的参数设置
 int xcd=300,ycd=300,zcd=300,xyspeed=3600,zspeed=600;
 int hcsd=600,xzkg=0,xztime=0; ;
 int lbts=10;//列表条数
 int ptkg = 0;

//设置背景kg
 int bjkg1 = 0,bjkg2 = 0;
//开机循环发送脉冲等参数
int stepkg=0;


 bool canSend = false;
 FILE* f;
 FILE* f2;
 vector<FileInfo> fileInfos;
 string currentDirectory;
 string fileName;

 // 获取当前时间，精确到ms
 int getCurrentTime() {
 	timeval tv;
 	gettimeofday(&tv, NULL);
 	return tv.tv_sec * 1000 + tv.tv_usec / 1000;  //毫秒
 }



 static bool onUI_Timer(int id);

 string addToTempItems(char* token) {
 	if (token[0] == '/') {
 		char* value = token + 1;
 		TempItem ti = { "", value };
 		tempItems.push_back(ti);
 		return "";
 	} else {
 		char header[4] = {0, };
 		char* value = strstr(token, ":") + 1;
 		strncpy(header, token, value - token - 1);
 		TempItem ti = { header, value };
 		tempItems.push_back(ti);
 		return header;
 	}
 }
 string addToAxis(char* token) {
 	        char ax[4] = {0, };
 			char* value = strstr(token, ":")+1 ;
 			strncpy(ax, token, value - token - 1);
 			AxIs ai = { ax, value };
 			Axis.push_back(ai);
 			return ax;
 	}



 struct csNum {
 	string va;
 };



 void printinit(){
	 kg1=0;
	// tempkg=1;
	//	mTextview10Ptr->setText("");
 	times=0;timef=0;times=0;timeh=0;//打印机时间归零
   //  printok = 0;        //打印完标志
	// homeok=0;
 }



 // 发送一行
 static void sendLine() {

 }
 void printGCode(string file, int index) {

 	sendLine();
 }

 // 列出TF卡中的文件夹
 void listFiles(string folder, string subFolder) {

 	mLVFolderPtr->refreshListView();

 }









 namespace { // 加个匿名作用域，防止多个源文件定义相同类名，运行时冲突
 // 实现自己的监听接口
 class MySlidePageChangeListener : public ZKSlideWindow::ISlidePageChangeListener {
 public:
     virtual void onSlidePageChange(ZKSlideWindow *pSlideWindow, int page) {
         LOGD("page: %d\n", page);
     }
 };
 }
 // 定义监听对象
 static MySlidePageChangeListener ptSlidePageChangeListener;

 /**
  * 当界面构造时触发
  */
 static void onUI_init(){
     //Tips :添加 UI初始化的显示代码到这里,如:mText1Ptr->setText("123");
		listFiles("/mnt", ".");





 }

 /**
  * 当切换到该界面时触发
  */
 static void onUI_intent(const Intent *intentPtr) {
     if (intentPtr != NULL) {
         //TODO
     }
 }

 /*
  * 当界面显示时触发
  */
 static void onUI_show() {
	 strs.push_back("Click here to send order") ;
	 	sprintf(id, "%d%d%d%d%d%d%d%d", devID[0],devID[1],devID[2],devID[3],devID[4],devID[5],devID[6],devID[7]);
	     char* lock = strstr(key2, id);//验证当前屏幕id是否在key里
//如果不在key里就弹出充值中心窗口，不让其他人进入系统
	 // if (lock == NULL){
	 //	 mTextview38Ptr->setText(id);
	 //	mczzxPtr->setVisible(true);
	 //	}



   //开机密码
 	std::string key = StoragePreferences::getString("key", "");
 	if(strcmp(key.c_str(),"")==0){

 		mlockPtr->setVisible(false);
 		}
 	else{
     if(strcmp(key.c_str(),"0")>0){
     mlockPtr->setVisible(true);}
 	}

	std::string zsf = StoragePreferences::getString("zs", "");
		if(strcmp(zsf.c_str(),"")!=0)
			hcsd = atoi(zsf.c_str());
			else
			hcsd = 600;
 }

 /*
  * 当界面隐藏时触发
  */
 static void onUI_hide() {

 }

 /*
  * 当界面完全退出时触发
  */
 static void onUI_quit() {




 }










 /**
  * 串口数据回调接口
  */

 // 处理没有ok的字符串
 void processPrinterCodeLine(string strLine) {

 }

 static void onProtocolDataUpdate(const SProtocolData &data) {


 }
 /**
  * 定时器触发函数
  * 不建议在此函数中写耗时操作，否则将影响UI刷新
  * 参数： id
  *         当前所触发定时器的id，与注册时的id相同
  * 返回值: true
  *             继续运行当前定时器
  *         false
  *             停止运行当前定时器
  */

 static bool onUI_Timer(int id){

	 if(id==2){
	if(xztime>0){//卸载按钮动画展示

		mButton33Ptr->setBackgroundPic("whclkgjk.png");
		xztime--;
		if(xztime==0)
		mButton33Ptr->setBackgroundPic("whclkgjg.png");
	}
	if(xztime<0){//卸载按钮动画展示

		mButton32Ptr->setBackgroundPic("whclkgck.png");
		xztime++;
		if(xztime==0)
		mButton32Ptr->setBackgroundPic("whclkgcg.png");
	}
		    if(TR>0){
		    	static int CS = 0;
		  	char path[50] = {0};
		  	if(ptkg==2){
		  	snprintf(path, sizeof(path), "whdt%d.png", CS);
		  	mTextView39Ptr->setBackgroundPic(path);}
		  	 if(ptkg == 1){
		  		snprintf(path, sizeof(path), "tempbj%d.png", CS);
		  		  	mTextView4Ptr->setBackgroundPic(path);}
		  	   CS++;
	        if(CS == 6){
		     CS =0;
	         TR--;}
		    }

	         if(TL>0){
	         static int CS = 6;
	         CS--;
			 char path[50] = {0};
			  	if(ptkg==2){
			  	snprintf(path, sizeof(path), "whdt%d.png", CS);
			  	mTextView39Ptr->setBackgroundPic(path);}
			  	 if(ptkg == 1){
			  		snprintf(path, sizeof(path), "tempbj%d.png", CS);
			  		  	mTextView4Ptr->setBackgroundPic(path);}

			 if(CS == 0){
			 	CS =6;
			     TL--;}}}




//这里是检测当前有没有按下异形按钮，避免在定时器里重复刷新按钮背景
	  if(mButton26Ptr->isPressed()){
	    			 mTextView1Ptr->setBackgroundPic("movexhome.png");
	    			 bjkg1 = 1;
	  }
	    		 else if(mButton27Ptr->isPressed()){
	    			 mTextView1Ptr->setBackgroundPic("moveyhome.png");
	    			 bjkg1 = 1;
	    		 }
	    		 else if(mButton28Ptr->isPressed()){
	    			 mTextView1Ptr->setBackgroundPic("movezhome.png");
	    			 bjkg1 = 1;
	    		 }
	    		 else if(mButton26Ptr->isPressed()==false&&mButton27Ptr->isPressed()==false&&mButton28Ptr->isPressed()==false&&bjkg1 == 1)
	    		 {	 mTextView1Ptr->setBackgroundPic("movebj.png");bjkg1 = 0;
	    		 }



     return true;
 }



 /**
  * 有新的触摸事件时触发
  * 参数：ev
  *         新的触摸事件
  * 返回值：true
  *            表示该触摸事件在此被拦截，系统不再将此触摸事件传递到控件上
  *         false
  *            触摸事件将继续传递到控件上
  */
 static bool ongcodeActivityTouchEvent(const MotionEvent &ev) {


     switch (ev.mActionStatus) {
 		case MotionEvent::E_ACTION_DOWN://触摸按下
 			//LOGD("时刻 = %ld 坐标  x = %d, y = %d", ev.mEventTime, ev.mX, ev.mY);
 			break;
 		case MotionEvent::E_ACTION_MOVE://触摸滑动
 			break;
 		case MotionEvent::E_ACTION_UP:  //触摸抬起
 			break;
 		default:
 			break;
 	}
 	return false;
 }
 static bool onButtonClick_btnPause(ZKButton *pButton) {//暂停打印
     //LOGD(" ButtonClick btnPause !!!\n");

 	pButton->setSelected(!pButton->isSelected());
     return false;
 }




 static bool onButtonClick_btnPrintOK(ZKButton *pButton) {//************************************************开始打印***************************************************************
     //LOGD(" ButtonClick btnPrintOK !!!\n");

	 mwinPrintPtr->showWnd();
	 mboardsdPtr->setVisible(true);
	 mwinQueryPrintPtr->hideWnd();
	 canSend=true;


	      return false;
 }

 static bool onButtonClick_btnPrintCancel(ZKButton *pButton) {
     //LOGD(" ButtonClick btnPrintCancel !!!\n");
		//mButton61Ptr->setVisible(true);
		//mButton60Ptr->setVisible(true);
 	mwinQueryPrintPtr->hideWnd();

     return false;
 }





 static int getListItemCount_LVFolder(const ZKListView *pListView) {
     //LOGD("getListItemCount_LVFolder !\n");
     return fileInfos.size();
 }

 static void obtainListItemData_LVFolder(ZKListView *pListView,ZKListView::ZKListItem *pListItem, int index) {


 }

 //文件页面
 static void onListItemClick_LVFolder(ZKListView *pListView, int index, int id) {

 }
 static bool onButtonClick_btnBack(ZKButton *pButton) {//********************************************停止打印*******************************************************************************
     //LOGD(" ButtonClick btnBack !!!\n");


 	if(statkg != 0)//如果没打印完
 	printcel=1;//取消打印标志
 	canSend = false;
 	gcode.clear();
 	mwinPrintPtr->hideWnd();



     return false;
 }



 //加热开关
 static bool onButtonClick_Button2(ZKButton *pButton) {
 	//LOGD(" ButtonClick Button2 !!!\n");

 	return false;
 }
 static bool onButtonClick_Button3(ZKButton *pButton) {
 	//LOGD(" ButtonClick Button3 !!!\n");
	 curprintcs = 30;
	 mAJPtr->setVisible(true);
 	return false;
 }




 static bool onButtonClick_Button17(ZKButton *pButton) {
	 std::string wifiname = StoragePreferences::getString("wifiname", "");
	 std::string wifipassword = StoragePreferences::getString("wifipassword", "");


 			    return false;
 		}




 static bool onButtonClick_Button1(ZKButton *pButton) {

 	    return false;
 }
 static bool onButtonClick_Button20(ZKButton *pButton) {
     //LOGD(" ButtonClick Button20 !!!\n");


 		    return false;
 }

 static bool onButtonClick_Button21(ZKButton *pButton) {
     //LOGD(" ButtonClick Button21 !!!\n");

     return false;
 }

 static bool onButtonClick_Button22(ZKButton *pButton) {
     //LOGD(" ButtonClick Button22 !!!\n");

 	    return false;
 }

 static bool onButtonClick_Button23(ZKButton *pButton) {
     //LOGD(" ButtonClick Button23 !!!\n");

     return false;
 }

 static bool onButtonClick_Button24(ZKButton *pButton) {
     //LOGD(" ButtonClick Button24 !!!\n");

 		    return false;
 }

 static bool onButtonClick_Button25(ZKButton *pButton) {
     //LOGD(" ButtonClick Button25 !!!\n");

 	    return false;
 }

 static bool onButtonClick_Button26(ZKButton *pButton) {
     //LOGD(" ButtonClick Button26 !!!\n");

     return false;
 }

 static bool onButtonClick_Button27(ZKButton *pButton) {
     //LOGD(" ButtonClick Button27 !!!\n");

     return false;
 }

 static bool onButtonClick_Button28(ZKButton *pButton) {
     //LOGD(" ButtonClick Button28 !!!\n");


 	    return false;
 }

 static int getListItemCount_Listview1(const ZKListView *pListView) {
     //LOGD("getListItemCount_Listview1 !\n");
 	return sizeof(sDataTestTab) / sizeof(S_TEST_DATA);
 }

 static void obtainListItemData_Listview1(ZKListView *pListView,ZKListView::ZKListItem *pListItem, int index) {
 	ZKListView::ZKListSubItem* psubButton = pListItem->findSubItemByID(ID_GCODE_SubItem1);
 	pListItem->setText(sDataTestTab[index].mainText);
 	psubButton->setSelected(sDataTestTab[index].bOn);
 }

 static void onListItemClick_Listview1(ZKListView *pListView, int index, int id) {
     //LOGD(" onListItemClick_ Listview1  !!!\n");
 	//sDataTestTab[index].bOn = !sDataTestTab[index].bOn;
 	    sDataTestTab[0].bOn = false;
 		sDataTestTab[1].bOn = false;
 		sDataTestTab[2].bOn = false;
 		sDataTestTab[3].bOn = false;
 		sDataTestTab[index].bOn = true;
 		switch (index){
 		case 0: jl=100;break;
 		case 1: jl=10;break;
 		case 2: jl=1;break;
 		case 3: jl=0.1;break;

 		}

 }


 static bool onButtonClick_Button32(ZKButton *pButton) {
     //LOGD(" ButtonClick Button32 !!!\n");


     return false;
 }

 static bool onButtonClick_Button33(ZKButton *pButton) {
     //LOGD(" ButtonClick Button33 !!!\n");




     return false;
 }




 static void onEditTextChanged_Edittext2(const std::string &text) {
     //LOGD(" onEditTextChanged_ Edittext2 %s !!!\n", text.c_str());

 }

 static bool onButtonClick_Button41(ZKButton *pButton) {
     //LOGD(" ButtonClick Button41 !!!\n");

     return false;
 }




 static bool onButtonClick_Button48(ZKButton *pButton) {
     //LOGD(" ButtonClick Button48 !!!\n");
 	 StoragePreferences::putString("key", mEdittext2Ptr->getText().c_str());
 	 mTextview53Ptr->setText("保存成功");

     return false;
 }


 static void onEditTextChanged_Edittext3(const std::string &text) {
     //LOGD(" onEditTextChanged_ Edittext3 %s !!!\n", text.c_str());
 	std::string key = StoragePreferences::getString("key", "null");
 	if(strcmp( key.c_str(), text.c_str())== 0){

 		mlockPtr->setVisible(false);
         lockkg=1;
 	}
 	else
 		//LOGD("输入内容：%s,data密码：%s",text.c_str(),key.c_str());
 		mTextview50Ptr->setText("密码输入错误");
 }

 static bool onButtonClick_Button50(ZKButton *pButton) {
     //LOGD(" ButtonClick Button50 !!!\n");


     return false;
 }
 static void onProgressChanged_Seekbar3(ZKSeekBar *pSeekBar, int progress) {
     //LOGD(" ProgressChanged Seekbar3 %d !!!\n", progress);
 	BRIGHTNESSHELPER->setBrightness(progress);
 	mTextview54Ptr->setText(progress);
 }
 static bool onButtonClick_Button49(ZKButton *pButton) {
     //LOGD(" ButtonClick Button49 !!!\n");

     return false;
 }
 static bool onButtonClick_Button51(ZKButton *pButton) {
     //LOGD(" ButtonClick Button51 !!!\n");
     return false;
 }




 static void onProgressChanged_Seekbar4(ZKSeekBar *pSeekBar, int progress) {
     //LOGD(" ProgressChanged Seekbar4 %d !!!\n", progress);



 }

 static void onEditTextChanged_Edittext4(const std::string &text) {
     //LOGD(" onEditTextChanged_ Edittext4 %s !!!\n", text.c_str());
 	StoragePreferences::putString("printpause", text.c_str());
 }




static void onProgressChanged_SeekBar1(ZKSeekBar *pSeekBar, int progress) {
    //LOGD(" ProgressChanged SeekBar1 %d !!!\n", progress);
}
static void onProgressChanged_SeekBar2(ZKSeekBar *pSeekBar, int progress) {
    //LOGD(" ProgressChanged SeekBar2 %d !!!\n", progress);
}

static void onProgressChanged_SeekBar3(ZKSeekBar *pSeekBar, int progress) {
    //LOGD(" ProgressChanged SeekBar3 %d !!!\n", progress);
}



void  setxs(ZKButton *pButton,int a){
	mmovePtr->setVisible(false);
	mtempPtr->setVisible(false);
	mprintPtr->setVisible(false);
	mWHPtr->setVisible(false);
	mmorePtr->setVisible(false);
    mButton70Ptr->setSelected(pButton->isPressed());
    mButton71Ptr->setSelected(pButton->isPressed());
    mButton72Ptr->setSelected(pButton->isPressed());
    mButton73Ptr->setSelected(pButton->isPressed());
    mButton74Ptr->setSelected(pButton->isPressed());

	switch(a){
	case 1:mmovePtr->setVisible(true);       kg1=1;          break;
	case 2:mtempPtr->setVisible(true);       kg1=0;          break;
	case 3:mprintPtr->setVisible(true);      kg1=2;          break;
	case 4:mWHPtr->setVisible(true);         kg1=1;          break;
	case 5:mmorePtr->setVisible(true);       kg1=1;          break;

	}}








static bool onButtonClick_Button70(ZKButton *pButton) {
	 setxs(pButton,1);

    mTextView3Ptr->setBackgroundPic("movexj.png");
    pButton->setSelected(!pButton->isSelected());
    return false;
}

static bool onButtonClick_Button71(ZKButton *pButton) {
	 setxs(pButton,2);
	 mButton3Ptr->setText(tempptwd);
    pButton->setSelected(!pButton->isSelected());
    mTextView3Ptr->setBackgroundPic("tempxj.png");
    return false;
}

static bool onButtonClick_Button72(ZKButton *pButton) {


	mLVFolderPtr->setSelection(1);//跳转到第一行
	    setxs(pButton,3);
	    pButton->setSelected(!pButton->isSelected());
        mTextView3Ptr->setBackgroundPic("printxj.png");

		if(canSend==true)
			mwinPrintPtr->setVisible(true);
		else
		mfishPtr->setVisible(true);











    return false;
}

static bool onButtonClick_Button73(ZKButton *pButton) {

	setxs(pButton,4);
	  pButton->setSelected(!pButton->isSelected());
     mTextView3Ptr->setBackgroundPic("whxj.png");


    return false;
}

static bool onButtonClick_Button74(ZKButton *pButton) {
	//mwifiPtr->setVisible(true);
    setxs(pButton,5);

    std::string wifiname = StoragePreferences::getString("wifiname", "");
    std::string wifipassword = StoragePreferences::getString("wifipassword", "");
    mEditText1Ptr ->setText(wifiname.c_str());
    mEditText2Ptr ->setText(wifipassword.c_str());

    pButton->setSelected(!pButton->isSelected());
    mTextView3Ptr->setBackgroundPic("morexj.png");

    return false;
}



static bool onButtonClick_Button75(ZKButton *pButton) {



    if (!pButton->isSelected()){//切换到热床
    	 mtemprcPtr->setVisible(true);
    	 mtempptPtr->setVisible(false);
    	 mButton6Ptr->setText(temprcwd);
    }
    else{ mtemprcPtr->setVisible(false);
        mtempptPtr->setVisible(true);}
        	pButton->setSelected(!pButton->isSelected());


    return false;
}

static bool onButtonClick_Button76(ZKButton *pButton) {
   // LOGD(" ButtonClick Button76 !!!\n");
tempptwd++;
mButton3Ptr->setText(tempptwd);


    return false;
}

static bool onButtonClick_Button77(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button77 !!!\n");


               	pButton->setSelected(!pButton->isSelected());


    return false;
}




static bool onButtonClick_Button78(ZKButton *pButton) {
    //LOGD(" ButtonClick Button78 !!!\n");

 	//printGCode(fileName, currentLine);
 	pButton->setSelected(!pButton->isSelected());
    return false;
}
static bool onButtonClick_Button79(ZKButton *pButton) {

	if (!pButton->isSelected()) {


		mprintcsPtr->showWnd();
	 	}
	 	else {	mprintcsPtr->hideWnd();

	 	}
	pButton->setSelected(!pButton->isSelected());

    return false;
}

void sendfail(){
	fsfail = 1;
LOGD("SENDFAIL");

}


static bool onButtonClick_Button80(ZKButton *pButton) {
   // LOGD(" ButtonClick Button80 !!!\n");
    mAJPtr->showWnd();
    curprintcs = 0;
    return false;
}

static bool onButtonClick_Button81(ZKButton *pButton) {
   // LOGD(" ButtonClick Button81 !!!\n");
	mAJPtr->showWnd();
    curprintcs = 1;
    return false;
}

static bool onButtonClick_Button82(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button82 !!!\n");
	mAJPtr->showWnd();
    curprintcs = 2;
    return false;
}

static bool onButtonClick_Button83(ZKButton *pButton) {
   // LOGD(" ButtonClick Button83 !!!\n");
	mAJPtr->showWnd();
    curprintcs = 3;
    return false;
}
static bool onButtonClick_Button84(ZKButton *pButton) {
	//LOGD(" ButtonClick Button84 !!!\n");
	addOneChar(pButton->getText()[0]);
    return false;
}
static bool onButtonClick_Button85(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button85 !!!\n");
	addOneChar(pButton->getText()[0]);
    return false;
}
static bool onButtonClick_Button86(ZKButton *pButton) {
   // LOGD(" ButtonClick Button86 !!!\n");
	addOneChar(pButton->getText()[0]);
    return false;
}

static bool onButtonClick_Button87(ZKButton *pButton) {
   // LOGD(" ButtonClick Button87 !!!\n");
	addOneChar(pButton->getText()[0]);
    return false;
}

static bool onButtonClick_Button88(ZKButton *pButton) {
   // LOGD(" ButtonClick Button88 !!!\n");
	addOneChar(pButton->getText()[0]);
    return false;
}

static bool onButtonClick_Button89(ZKButton *pButton) {
   // LOGD(" ButtonClick Button89 !!!\n");
	addOneChar(pButton->getText()[0]);
    return false;
}
static bool onButtonClick_Button90(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button90 !!!\n");
	addOneChar(pButton->getText()[0]);
    return false;
}
static bool onButtonClick_Button91(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button91 !!!\n");
	addOneChar(pButton->getText()[0]);
    return false;
}
static bool onButtonClick_Button92(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button92 !!!\n");
	addOneChar(pButton->getText()[0]);
    return false;
}
static bool onButtonClick_Button93(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button93 !!!\n");
 	mAJPtr->hideWnd();
 	sContentStr.clear();
	mTextView22Ptr->setText(sContentStr);
    return false;
}
static bool onButtonClick_Button94(ZKButton *pButton) {
   // LOGD(" ButtonClick Button94 !!!\n");
	addOneChar(pButton->getText()[0]);
    return false;
}
static bool onButtonClick_Button95(ZKButton *pButton) {
    //LOGD(" ButtonClick Button95 !!!\n");


 	sContentStr.clear();
	mTextView22Ptr->setText(sContentStr);
    return false;
}
static bool onButtonClick_Button96(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button96 !!!\n");
	delOneChar();
    return false;
}
static void onProgressChanged_SeekBar4(ZKSeekBar *pSeekBar, int progress) {
    //LOGD(" ProgressChanged SeekBar4 %d !!!\n", progress);



}

static void onProgressChanged_SeekBar5(ZKSeekBar *pSeekBar, int progress) {
    //LOGD(" ProgressChanged SeekBar5 %d !!!\n", progress);
}

static void onProgressChanged_SeekBar6(ZKSeekBar *pSeekBar, int progress) {
    //LOGD(" ProgressChanged SeekBar6 %d !!!\n", progress);
}
void  setwhbj(int a){
	mwhmovePtr->setVisible(false);
	mwhclPtr->setVisible(false);
	mwhtpPtr->setVisible(false);
	mwhcsPtr->setVisible(false);

	switch(a){
	case 0: mwhmovePtr->setVisible(true);mTextView37Ptr->setBackgroundPic("whsetbj.png");          break;
	case 1: mwhclPtr->setVisible(true);mTextView37Ptr->setBackgroundPic("whsetbj1.png");           break;
	case 2: mwhtpPtr->setVisible(true);mTextView37Ptr->setBackgroundPic("whsetbj2.png");           break;
	case 3: mwhcsPtr->setVisible(true); mTextView37Ptr->setBackgroundPic("whsetbj3.png");           break;
	//case 4: mTextView37Ptr->setBackgroundPic("whsetbj4.png");           break;
	//case 5: mTextView37Ptr->setBackgroundPic("whsetbj.png");           break;

	}
}
static bool onButtonClick_Button97(ZKButton *pButton) {
   // LOGD(" ButtonClick Button97 !!!\n");
	kg1=1;
	setwhbj(0);
    return false;
}

static bool onButtonClick_Button98(ZKButton *pButton) {
 //   LOGD(" ButtonClick Button98 !!!\n");

	kg1=0;
	setwhbj(1);
    return false;
}

static bool onButtonClick_Button99(ZKButton *pButton) {
 //   LOGD(" ButtonClick Button99 !!!\n");
	setwhbj(2);
    return false;
}

static bool onButtonClick_Button100(ZKButton *pButton) {
 //   LOGD(" ButtonClick Button100 !!!\n");
	setwhbj(3);
	char buf[50];
	std::string xcdf = StoragePreferences::getString("Xcd", "");//X长度
	std::string ycdf = StoragePreferences::getString("Ycd", "");//X长度
	std::string zcdf = StoragePreferences::getString("Zcd", "");//X长度
	std::string xyspeedf = StoragePreferences::getString("XYspeed", "");//X长度
	std::string zspeedf = StoragePreferences::getString("Zspeed", "");//X长度

	if(strcmp(xcdf.c_str(),"")!=0)
		sprintf(buf,"Xaxis length：%s",xcdf.c_str());
		else
		sprintf(buf,"Xaxis length：%d",xcd);
		mButton110Ptr->setText(buf);

		if(strcmp(ycdf.c_str(),"")!=0)
		sprintf(buf,"Yaxis length：%s",ycdf.c_str());
			else
		sprintf(buf,"Yaxis length：%d",ycd);
		mButton111Ptr->setText(buf);

		if(strcmp(zcdf.c_str(),"")!=0)
		sprintf(buf,"Zaxis length：%s",zcdf.c_str());
			else
		sprintf(buf,"Zaxis length：%d",zcd);
		mButton112Ptr->setText(buf);


		if(strcmp(xyspeedf.c_str(),"")!=0)
		sprintf(buf,"XY move speed：%s",xyspeedf.c_str());
			else
		sprintf(buf,"XY move speed：%d",xyspeed);
		mButton113Ptr->setText(buf);


		if(strcmp(zspeedf.c_str(),"")!=0)
		sprintf(buf,"Z move speed：%s",zspeedf.c_str());
			else
		sprintf(buf,"Z move speed：%d",zspeed);
		mButton114Ptr->setText(buf);

		std::string hccdf = StoragePreferences::getString("hccd", "");//
		std::string dsf = StoragePreferences::getString("ds", "");//
		std::string csf = StoragePreferences::getString("cs", "");//
		std::string gsf = StoragePreferences::getString("gs", "");//

		if(strcmp(hccdf.c_str(),"")!=0)
			sprintf(buf,"Extrusion length：%s",hccdf.c_str());
				else
			sprintf(buf,"Extrusion length：100");
			mButton115Ptr->setText(buf);

			if(strcmp(dsf.c_str(),"")!=0)
				sprintf(buf,"LOW speed：%s",dsf.c_str());
					else
				sprintf(buf,"LOW speed：300");
				mButton116Ptr->setText(buf);

				if(strcmp(csf.c_str(),"")!=0)
					sprintf(buf,"Constant speed：%s",csf.c_str());
						else
					sprintf(buf,"Constant speed：600");
					mButton117Ptr->setText(buf);

					if(strcmp(gsf.c_str(),"")!=0)
						sprintf(buf,"HIGH speed：%s",gsf.c_str());
							else
						sprintf(buf,"HIGH speed：1800");
						mButton118Ptr->setText(buf);

    return false;
}
static bool onButtonClick_Button101(ZKButton *pButton) {
    //LOGD(" ButtonClick Button101 !!!\n");
	mTextView38Ptr->setBackgroundPic("whclsdds.png");
	std::string dsf = StoragePreferences::getString("ds", "");
		if(strcmp(dsf.c_str(),"")!=0)
			hcsd = atoi(dsf.c_str());
			else
			hcsd = 300;
    return false;
}
static bool onButtonClick_Button102(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button102 !!!\n");
	std::string zsf = StoragePreferences::getString("zs", "");
	mTextView38Ptr->setBackgroundPic("whclsdcs.png");
	if(strcmp(zsf.c_str(),"")!=0)
		hcsd = atoi(zsf.c_str());
		else
		hcsd = 600;
    return false;
}

static bool onButtonClick_Button103(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button103 !!!\n");
	mTextView38Ptr->setBackgroundPic("whclsdgs.png");
	std::string gsf = StoragePreferences::getString("gs", "");
			if(strcmp(gsf.c_str(),"")!=0)
				hcsd = atoi(gsf.c_str());
				else
				hcsd = 1800;
    return false;
}
static bool onButtonClick_Button104(ZKButton *pButton) {
   // LOGD(" ButtonClick Button104 !!!\n");
	ptkg=2;
	TL++;
	whT++;

	char buf[50];
	  //sprintf(buf,"Z:%s",Axis[2].va.c_str());
	if(whT>6)
		whT=0;
		  sprintf(buf,"Nozzle%d",whT);
		  mTextView4Ptr->setText(buf);
		  mTextView39Ptr->setText(buf);
		sprintf(buf,"T%d\r\n",whT);

    return false;
}

static bool onButtonClick_Button105(ZKButton *pButton) {
    //LOGD(" ButtonClick Button105 !!!\n");
	ptkg=2;
	TR++;
	whT--;

	char buf[50];
	  //sprintf(buf,"Z:%s",Axis[2].va.c_str());
	if(whT<0)
		whT=6;
		  sprintf(buf,"Nozzle%d",whT);
		  mTextView4Ptr->setText(buf);
		  mTextView39Ptr->setText(buf);
		  sprintf(buf,"T%d\r\n",whT);


    return false;
}
static int getListItemCount_ListView1(const ZKListView *pListView) {
    //LOGD("getListItemCount_ListView1 !\n");
	return sizeof(Gcode) / sizeof(gcodeml);

}

static void obtainListItemData_ListView1(ZKListView *pListView,ZKListView::ZKListItem *pListItem, int index) {
    //LOGD(" obtainListItemData_ ListView1  !!!\n");
	pListItem->setText(Gcode[index].mainText);
}

static void onListItemClick_ListView1(ZKListView *pListView, int index, int id) {
    //LOGD(" onListItemClick_ ListView1  !!!\n");
	 mTextView45Ptr->setText(Gcode[index].nrText);

}
static bool onButtonClick_Button109(ZKButton *pButton) {
    //LOGD(" ButtonClick Button109 !!!\n");
	curprintcs = 40;
	 mAJ1Ptr->showWnd();
    return false;
}

void  setmorebj(int a){
	mmorehmlPtr->setVisible(false);
	mmoregjPtr->setVisible(false);
	mmorepmsetPtr->setVisible(false);
	mwifiPtr->setVisible(false);

	switch(a){
	case 0: mwifiPtr->setVisible(true);mTextView43Ptr->setBackgroundPic("morebj0.png");           break;
	case 1: mmoregjPtr->setVisible(true);mTextView43Ptr->setBackgroundPic("morebj1.png");          break;
	case 2: mmorehmlPtr->setVisible(true);mTextView43Ptr->setBackgroundPic("morebj2.png");           break;
	case 3: mmorepmsetPtr->setVisible(true);mTextView43Ptr->setBackgroundPic("morebj3.png");           break;

	}
}


static bool onButtonClick_Button12(ZKButton *pButton) {
   // LOGD(" ButtonClick Button12 !!!\n");
	 setmorebj(0);
    return false;
}

static bool onButtonClick_Button106(ZKButton *pButton) {
   // LOGD(" ButtonClick Button106 !!!\n");
	 setmorebj(1);
    return false;
}

static bool onButtonClick_Button107(ZKButton *pButton) {
   // LOGD(" ButtonClick Button107 !!!\n");
	 setmorebj(2);
kg1=4;
    return false;
}

static bool onButtonClick_Button108(ZKButton *pButton) {
   // LOGD(" ButtonClick Button108 !!!\n");
	 setmorebj(3);
    return false;
}
static bool onButtonClick_Button110(ZKButton *pButton) {
    //LOGD(" ButtonClick Button110 !!!\n");
    mAJ1Ptr->showWnd();
    curprintcs = 10;
	//StoragePreferences::putString("printpause", text.c_str());

    return false;
}

static bool onButtonClick_Button111(ZKButton *pButton) {
   // LOGD(" ButtonClick Button111 !!!\n");
    mAJ1Ptr->showWnd();
    curprintcs = 11;
    return false;
}

static bool onButtonClick_Button112(ZKButton *pButton) {
   // LOGD(" ButtonClick Button112 !!!\n");
    mAJ1Ptr->showWnd();
    curprintcs = 12;
    return false;
}

static bool onButtonClick_Button113(ZKButton *pButton) {
   // LOGD(" ButtonClick Button113 !!!\n");
    mAJ1Ptr->showWnd();
    curprintcs = 13;
    return false;
}

static bool onButtonClick_Button114(ZKButton *pButton) {
   // LOGD(" ButtonClick Button114 !!!\n");
    mAJ1Ptr->showWnd();
    curprintcs = 14;
    return false;
}

static bool onButtonClick_Button115(ZKButton *pButton) {
   // LOGD(" ButtonClick Button115 !!!\n");
    mAJ1Ptr->showWnd();
    curprintcs = 15;
    return false;
}

static bool onButtonClick_Button116(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button116 !!!\n");
    mAJ1Ptr->showWnd();
    curprintcs = 16;
    return false;
}

static bool onButtonClick_Button117(ZKButton *pButton) {
   // LOGD(" ButtonClick Button117 !!!\n");
    mAJ1Ptr->showWnd();
    curprintcs = 17;
    return false;
}

static bool onButtonClick_Button118(ZKButton *pButton) {
   // LOGD(" ButtonClick Button118 !!!\n");
    mAJ1Ptr->showWnd();
    curprintcs = 18;
    return false;
}

static bool onButtonClick_Button119(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button119 !!!\n");
    return false;
}

static bool onButtonClick_Button120(ZKButton *pButton) {
    //LOGD(" ButtonClick Button120 !!!\n");
    return false;
}

static bool onButtonClick_Button121(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button121 !!!\n");
    return false;
}

static bool onButtonClick_Button122(ZKButton *pButton) {
 //   LOGD(" ButtonClick Button122 !!!\n");
    return false;
}

static bool onButtonClick_Button123(ZKButton *pButton) {
   // LOGD(" ButtonClick Button123 !!!\n");
    return false;
}

static bool onButtonClick_Button124(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button124 !!!\n");
    return false;
}
static bool onButtonClick_Button125(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button125 !!!\n");
    return false;
}
static bool onButtonClick_Button126(ZKButton *pButton) {
   // LOGD(" ButtonClick Button126 !!!\n");


	//mAJ1Ptr->hideWnd();
	switch(curprintcs){

	case 10: StoragePreferences::putString("Xcd", sContentStr.c_str());break;
	case 11: StoragePreferences::putString("Ycd", sContentStr.c_str());break;
	case 12: StoragePreferences::putString("Zcd", sContentStr.c_str());break;
	case 13: StoragePreferences::putString("XYspeed", sContentStr.c_str());break;
	case 14: StoragePreferences::putString("Zspeed", sContentStr.c_str());break;

	/*
	 * 耗材装载参数设置
	 */

	case 15: StoragePreferences::putString("hccd", sContentStr.c_str());break;
	case 16: StoragePreferences::putString("ds", sContentStr.c_str());break;
	case 17: StoragePreferences::putString("cs", sContentStr.c_str());break;
	case 18: StoragePreferences::putString("gs", sContentStr.c_str());break;










	case 100:
	         char buf[150];
	        		 sprintf(buf,"Send：%s\r\n",sContentStr.c_str());
	        		 strs.push_back(buf) ;
	        		 gindex++;
	        		 mListView2Ptr->refreshListView();
	        		 mListView2Ptr->setSelection(gindex-2);break;
	}
	std::string xcdf = StoragePreferences::getString("Xcd", "");//X
	std::string ycdf = StoragePreferences::getString("Ycd", "");//X长度
	std::string zcdf = StoragePreferences::getString("Zcd", "");//X长度
	std::string xyspeedf = StoragePreferences::getString("XYspeed", "");//X长度
	std::string zspeedf = StoragePreferences::getString("Zspeed", "");//X长度

	std::string hccdf = StoragePreferences::getString("hccd", "");//耗材长度
	std::string dsf = StoragePreferences::getString("ds", "");//低速
	std::string csf = StoragePreferences::getString("cs", "");//常速
	std::string gsf = StoragePreferences::getString("gs", "");//高速



char buf[100];
switch(curprintcs){
case 10:sprintf(buf,"Xaxis length：%s",xcdf.c_str());mButton110Ptr->setText(buf); break;
case 11:sprintf(buf,"Yaxis length：%s",ycdf.c_str());mButton111Ptr->setText(buf); break;
case 12:sprintf(buf,"Zaxis length：%s",zcdf.c_str());mButton112Ptr->setText(buf); break;
case 13:sprintf(buf,"XY move speed：%s",xyspeedf.c_str());mButton113Ptr->setText(buf); break;
case 14:sprintf(buf,"Z move speed：%s",zspeedf.c_str());mButton114Ptr->setText(buf); break;




case 15:sprintf(buf,"Extrusion length：%s",hccdf.c_str());mButton115Ptr->setText(buf); break;
case 16:sprintf(buf,"LOW speed：%s",dsf.c_str());mButton116Ptr->setText(buf); break;
case 17:sprintf(buf,"Constant speed:%s",csf.c_str());mButton117Ptr->setText(buf); break;
case 18:sprintf(buf,"HIGH speed：%s",gsf.c_str());mButton118Ptr->setText(buf); break;







	}

	//backok++;


 	sContentStr.clear();
	mTextView46Ptr->setText("");
    return false;


	return false;
}

static bool onButtonClick_Button128(ZKButton *pButton) {
   // LOGD(" ButtonClick Button128 !!!\n");

	StoragePreferences::remove("Xcd");
	StoragePreferences::remove("Ycd");
	StoragePreferences::remove("Zcd");
	StoragePreferences::remove("XYspeed");
	StoragePreferences::remove("Zspeed");
	StoragePreferences::remove("hccd");
	StoragePreferences::remove("ds");
	StoragePreferences::remove("cs");
	StoragePreferences::remove("gs");
    char buf[50];
	sprintf(buf,"Xaxis length：%d",xcd);
	mButton110Ptr->setText(buf);
	sprintf(buf,"Yaxis length：%d",ycd);
	mButton111Ptr->setText(buf);
    sprintf(buf,"Zaxis length：%d",zcd);
	mButton112Ptr->setText(buf);
	sprintf(buf,"XY move speed：%d",xyspeed);
	mButton113Ptr->setText(buf);
	sprintf(buf,"Z move speed：%d",zspeed);
	mButton114Ptr->setText(buf);





    return false;
}

static bool onButtonClick_Button127(ZKButton *pButton) {
    //LOGD(" ButtonClick Button127 !!!\n");
	addOneChar('1');
    return false;
}
static bool onButtonClick_Button129(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button129 !!!\n");
	addOneChar('0');
    return false;
}

static bool onButtonClick_Button130(ZKButton *pButton) {
    //LOGD(" ButtonClick Button130 !!!\n");
    addOneChar('2');
    return false;
}

static bool onButtonClick_Button131(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button131 !!!\n");
	addOneChar('3');
    return false;
}

static bool onButtonClick_Button132(ZKButton *pButton) {
    //LOGD(" ButtonClick Button132 !!!\n");
	addOneChar('4');
    return false;
}

static bool onButtonClick_Button133(ZKButton *pButton) {
    //LOGD(" ButtonClick Button133 !!!\n");
	addOneChar('5');
    return false;
}

static bool onButtonClick_Button134(ZKButton *pButton) {
   // LOGD(" ButtonClick Button134 !!!\n");
	addOneChar('6');
    return false;
}

static bool onButtonClick_Button135(ZKButton *pButton) {
   // LOGD(" ButtonClick Button135 !!!\n");
	addOneChar('7');
    return false;
}

static bool onButtonClick_Button136(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button136 !!!\n");
	addOneChar('8');
    return false;
}

static bool onButtonClick_Button137(ZKButton *pButton) {
   // LOGD(" ButtonClick Button137 !!!\n");
    addOneChar('9');
    return false;
}

static bool onButtonClick_Button138(ZKButton *pButton) {
   // LOGD(" ButtonClick Button138 !!!\n");
    addOneChar('-');
    return false;
}

static bool onButtonClick_Button139(ZKButton *pButton) {
   // LOGD(" ButtonClick Button139 !!!\n");
	 addOneChar('.');
    return false;
}

static bool onButtonClick_Button140(ZKButton *pButton) {
   // LOGD(" ButtonClick Button140 !!!\n");
	 addOneChar('A');
    return false;
}

static bool onButtonClick_Button141(ZKButton *pButton) {
   // LOGD(" ButtonClick Button141 !!!\n");
	 addOneChar('B');
    return false;
}

static bool onButtonClick_Button142(ZKButton *pButton) {
    //LOGD(" ButtonClick Button142 !!!\n");
	 addOneChar('C');
    return false;
}

static bool onButtonClick_Button143(ZKButton *pButton) {
    //LOGD(" ButtonClick Button143 !!!\n");
	 addOneChar('D');
    return false;
}

static bool onButtonClick_Button144(ZKButton *pButton) {
    //LOGD(" ButtonClick Button144 !!!\n");
	 addOneChar('E');
    return false;
}

static bool onButtonClick_Button145(ZKButton *pButton) {
   // LOGD(" ButtonClick Button145 !!!\n");
	 addOneChar('F');
    return false;
}

static bool onButtonClick_Button146(ZKButton *pButton) {
   // LOGD(" ButtonClick Button146 !!!\n");
	 addOneChar('G');
    return false;
}

static bool onButtonClick_Button147(ZKButton *pButton) {
   // LOGD(" ButtonClick Button147 !!!\n");
	 addOneChar('H');
    return false;
}

static bool onButtonClick_Button148(ZKButton *pButton) {
   // LOGD(" ButtonClick Button148 !!!\n");
	 addOneChar('I');
    return false;
}

static bool onButtonClick_Button149(ZKButton *pButton) {
   // LOGD(" ButtonClick Button149 !!!\n");
	 addOneChar('J');
    return false;
}

static bool onButtonClick_Button150(ZKButton *pButton) {
   // LOGD(" ButtonClick Button150 !!!\n");
	 addOneChar('K');
    return false;
}

static bool onButtonClick_Button151(ZKButton *pButton) {
   // LOGD(" ButtonClick Button151 !!!\n");
	 addOneChar('L');
    return false;
}

static bool onButtonClick_Button152(ZKButton *pButton) {
   // LOGD(" ButtonClick Button152 !!!\n");
	 addOneChar('M');
    return false;
}

static bool onButtonClick_Button153(ZKButton *pButton) {
   // LOGD(" ButtonClick Button153 !!!\n");
	 addOneChar('N');
    return false;
}

static bool onButtonClick_Button154(ZKButton *pButton) {
   // LOGD(" ButtonClick Button154 !!!\n");
	 addOneChar('O');
    return false;
}

static bool onButtonClick_Button155(ZKButton *pButton) {
   // LOGD(" ButtonClick Button155 !!!\n");
	 addOneChar('P');
    return false;
}

static bool onButtonClick_Button156(ZKButton *pButton) {
   // LOGD(" ButtonClick Button156 !!!\n");
	 addOneChar('Q');
    return false;
}

static bool onButtonClick_Button157(ZKButton *pButton) {
   // LOGD(" ButtonClick Button157 !!!\n");
	 addOneChar('R');
    return false;
}

static bool onButtonClick_Button158(ZKButton *pButton) {
   // LOGD(" ButtonClick Button158 !!!\n");
	 addOneChar('S');
    return false;
}

static bool onButtonClick_Button159(ZKButton *pButton) {
   // LOGD(" ButtonClick Button159 !!!\n");
	 addOneChar('T');
    return false;
}

static bool onButtonClick_Button160(ZKButton *pButton) {
   // LOGD(" ButtonClick Button160 !!!\n");
	 addOneChar('U');
    return false;
}

static bool onButtonClick_Button161(ZKButton *pButton) {
    //LOGD(" ButtonClick Button161 !!!\n");
	 addOneChar('V');
    return false;
}

static bool onButtonClick_Button162(ZKButton *pButton) {
    //LOGD(" ButtonClick Button162 !!!\n");
	 addOneChar('W');
    return false;
}

static bool onButtonClick_Button163(ZKButton *pButton) {
    //LOGD(" ButtonClick Button163 !!!\n");
	 addOneChar('X');
    return false;
}

static bool onButtonClick_Button164(ZKButton *pButton) {
   // LOGD(" ButtonClick Button164 !!!\n");
	 addOneChar('Y');
    return false;
}

static bool onButtonClick_Button165(ZKButton *pButton) {
   // LOGD(" ButtonClick Button165 !!!\n");
	 addOneChar('Z');
    return false;
}
static bool onButtonClick_Button166(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button166 !!!\n");
	 addOneChar(' ');
    return false;
}

static bool onButtonClick_Button167(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button167 !!!\n");
	delOneChar();
    return false;
}

static bool onButtonClick_Button168(ZKButton *pButton) {
//    LOGD(" ButtonClick Button168 !!!\n");
    mAJ1Ptr->hideWnd();
    sContentStr.clear();
    	mTextView46Ptr->setText("");
    return false;
}

static int getListItemCount_ListView2(const ZKListView *pListView) {
    //LOGD("getListItemCount_ListView2 !\n");
    return gindex;
}

static void obtainListItemData_ListView2(ZKListView *pListView,ZKListView::ZKListItem *pListItem, int index) {
    //LOGD(" obtainListItemData_ ListView2  !!!\n");

	pListItem->setText(strs[index]);
//	pListItem->setText(shu[index]);
}

static void onListItemClick_ListView2(ZKListView *pListView, int index, int id) {
    //LOGD(" onListItemClick_ ListView2  !!!\n");
	curprintcs = 100;
	mAJ1Ptr->showWnd();
	// LOGD("%s",Gc[gindex].mainText);
}

static bool onButtonClick_Button178(ZKButton *pButton) {
   // LOGD(" ButtonClick Button178 !!!\n");
	ptkg=1;
	TR++;
	whT--;
	bjkg2=0;
	char buf[50];
	  //sprintf(buf,"Z:%s",Axis[2].va.c_str());
	if(whT<0)
		whT=6;
	  sprintf(buf,"Nozzle%d",whT);
		  mTextView4Ptr->setText(buf);
		  mTextView39Ptr->setText(buf);
		  sprintf(buf,"T%d\r\n",whT);

 	 	mButton77Ptr->setSelected(pButton->isSelected());
 	 	mTextView7Ptr->setBackgroundPic("temprcxsoff.png");


    return false;
}

static bool onButtonClick_Button179(ZKButton *pButton) {
    //LOGD(" ButtonClick Button179 !!!\n");
	ptkg=1;
	TL++;
		whT++;

		char buf[50];
		  //sprintf(buf,"Z:%s",Axis[2].va.c_str());
		if(whT>6)
			whT=0;
			sprintf(buf,"Nozzle%d",whT);
			mTextView4Ptr->setText(buf);
			mTextView39Ptr->setText(buf);
			sprintf(buf,"T%d\r\n",whT);

	 	 	mButton77Ptr->setSelected(false);
	 	 	mTextView7Ptr->setBackgroundPic("temprcxsoff.png");






    return false;
}
static bool onButtonClick_Button180(ZKButton *pButton) {
	 curprintcs = 30;
	 mAJPtr->setVisible(true);
    return false;
}

static bool onButtonClick_Button4(ZKButton *pButton) {
	 curprintcs = 31;
	mAJPtr->setVisible(true);
    return false;
}

static bool onButtonClick_Button5(ZKButton *pButton) {
	   if (!pButton->isSelected()){//加热开启

	    mTextView49Ptr->setBackgroundPic("temprcxson.png");
	   }
	      else{
	        mTextView49Ptr->setBackgroundPic("temprcxsoff.png");
	      }
             pButton->setSelected(!pButton->isSelected());


    return false;
}

static bool onButtonClick_Button6(ZKButton *pButton) {

    curprintcs = 31;
   	 mAJPtr->setVisible(true);
    return false;
}

static bool onButtonClick_Button7(ZKButton *pButton) {
	temprcwd--;
		mButton6Ptr->setText(temprcwd);
    return false;
}

static bool onButtonClick_Button8(ZKButton *pButton) {

	temprcwd++;
	mButton6Ptr->setText(temprcwd);
    return false;
}
static int getListItemCount_ListView3(const ZKListView *pListView) {
    //LOGD("getListItemCount_ListView3 !\n");
    return 10;
}

static void obtainListItemData_ListView3(ZKListView *pListView,ZKListView::ZKListItem *pListItem, int index) {
    //LOGD(" obtainListItemData_ ListView3  !!!\n");
	pListItem->setText(maxspeeds[index]);
}

static void onListItemClick_ListView3(ZKListView *pListView, int index, int id) {
    //LOGD(" onListItemClick_ ListView3  !!!\n");
	 mAJ1Ptr->setVisible(true);
	 switch(index){
	 case 0:curprintcs=59;break;
	 case 1:curprintcs=60;break;
	 case 2:curprintcs=61;break;
	 case 3:curprintcs=62;break;
	 case 4:curprintcs=63;break;
	 case 5:curprintcs=64;break;
	 case 6:curprintcs=65;break;
	 case 7:curprintcs=66;break;
	 case 8:curprintcs=67;break;


	 }
}
static int getListItemCount_ListView4(const ZKListView *pListView) {
    //LOGD("getListItemCount_ListView4 !\n");
    return 3;
}

static void obtainListItemData_ListView4(ZKListView *pListView,ZKListView::ZKListItem *pListItem, int index) {
    //LOGD(" obtainListItemData_ ListView4  !!!\n");
	pListItem->setText(PID[index]);
}

static void onListItemClick_ListView4(ZKListView *pListView, int index, int id) {
    //LOGD(" onListItemClick_ ListView4  !!!\n");
	 mAJ1Ptr->setVisible(true);
	 switch(index){
	 case 0:curprintcs=68;break;
	 case 1:curprintcs=69;break;
	 case 2:curprintcs=70;break;



	 }

}
static int getListItemCount_ListView5(const ZKListView *pListView) {
    //LOGD("getListItemCount_ListView5 !\n");

    return 9;
}

static void obtainListItemData_ListView5(ZKListView *pListView,ZKListView::ZKListItem *pListItem, int index) {
    //LOGD(" obtainListItemData_ ListView5  !!!\n");
	//pListItem->setText(STEP[index]);
}

static void onListItemClick_ListView5(ZKListView *pListView, int index, int id) {
    //LOGD(" onListItemClick_ ListView5  !!!\n");

	 mAJ1Ptr->setVisible(true);
	 switch(index){
	 case 0:curprintcs=50;break;
	 case 1:curprintcs=51;break;
	 case 2:curprintcs=52;break;
	 case 3:curprintcs=53;break;
	 case 4:curprintcs=54;break;
	 case 5:curprintcs=55;break;
	 case 6:curprintcs=56;break;
	 case 7:curprintcs=57;break;
	 case 8:curprintcs=58;break;


	 }


}
static bool onButtonClick_Button9(ZKButton *pButton) {
   // LOGD(" ButtonClick Button9 !!!\n");
	currmode = 0;

	//0 Thread::sleep(100);

	 mboardsdPtr->setVisible(true);
	 mfishPtr->setVisible(false);
    return false;
}

static bool onButtonClick_Button10(ZKButton *pButton) {
   // LOGD(" ButtonClick Button10 !!!\n");
	currmode = 1;
    return false;
}

static bool onButtonClick_Button11(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button11 !!!\n");
	currmode = 1;
	listFiles("/mnt", ".");
    return false;
}
static int getListItemCount_boardsd(const ZKListView *pListView) {
    //LOGD("getListItemCount_boardsd !\n");
    return 1;
}

static void obtainListItemData_boardsd(ZKListView *pListView,ZKListView::ZKListItem *pListItem, int index) {
    //LOGD(" obtainListItemData_ boardsd  !!!\n");
	pListItem->setText(gcodes[index]);
}

static void onListItemClick_boardsd(ZKListView *pListView, int index, int id) {
    //LOGD(" onListItemClick_ boardsd  !!!\n");
	 mwinQueryPrintPtr->setVisible(true);
	 xzgcodenum = index;





}
static void onEditTextChanged_EditText1(const std::string &text) {
    //LOGD(" onEditTextChanged_ EditText1 %s !!!\n", text.c_str());
	StoragePreferences::putString("wifiname", text.c_str());
}

static void onEditTextChanged_EditText2(const std::string &text) {
    //LOGD(" onEditTextChanged_ EditText2 %s !!!\n", text.c_str());
	StoragePreferences::putString("wifipassword", text.c_str());
}

static bool onButtonClick_Button13(ZKButton *pButton) {
   // LOGD(" ButtonClick Button13 !!!\n");

    return false;
}

static bool onButtonClick_Button14(ZKButton *pButton) {
   // LOGD(" ButtonClick Button14 !!!\n");


    return false;
}

static bool onButtonClick_Button15(ZKButton *pButton) {
   // LOGD(" ButtonClick Button15 !!!\n");


    return false;
}

static bool onButtonClick_Button16(ZKButton *pButton) {


 				    return false;
 	}


static bool onButtonClick_Button18(ZKButton *pButton) {
  //  LOGD(" ButtonClick Button18 !!!\n");


    return false;
}
static bool onButtonClick_Button39(ZKButton *pButton) {
    LOGD(" ButtonClick Button39 !!!\n");
    return false;
}

static bool onButtonClick_Button59(ZKButton *pButton) {
    LOGD(" ButtonClick Button59 !!!\n");
    return false;
}
